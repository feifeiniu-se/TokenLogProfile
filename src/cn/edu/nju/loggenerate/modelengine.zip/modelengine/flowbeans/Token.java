/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cn.edu.nju.software.modelengine.flowbeans;

/**
 *
 * @author LiChuanyi
 */
public class Token {
    
    private static int id = 1;
    public static void resetID(){
    	id = 1;
    }
    
    private int tokenID;
    
    private int produceTime;
    private int consumeTime;
    private int caseid;
    
    private int producer = -2;
    private int consumer = -1;
    
    private boolean isConsumed = false;
    
    public boolean handled = false;
    
    public Token(){
        this.tokenID = id;
        id ++;
    }

    public int getTokenID() {
        return tokenID;
    }

    public void setTokenID(int tokenID) {
        this.tokenID = tokenID;
    }

    public int getProduceTime() {
        return produceTime;
    }

    public void setProduceTime(int produceTime) {
        this.produceTime = produceTime;
    }

    public int getConsumeTime() {
        return consumeTime;
    }

    public void setConsumeTime(int consumeTime) {
        this.consumeTime = consumeTime;
    }

    public int getProducer() {
        return producer;
    }

    public void setProducer(int producer) {
        this.producer = producer;
    }

    public int getConsumer() {
        return consumer;
    }

    public void setConsumer(int consumer) {
        this.consumer = consumer;
    }

    public boolean isIsConsumed() {
        return isConsumed;
    }

    public void setIsConsumed(boolean isConsumed) {
        this.isConsumed = isConsumed;
    }

	public int getCaseid() {
		return caseid;
	}

	public void setCaseid(int caseid) {
		this.caseid = caseid;
	}

	public void print(){
		System.out.println(this.getCaseid()+":"+this.getTokenID()+":"+this.getProducer()+":"+this.getConsumer());
	}
	
}
