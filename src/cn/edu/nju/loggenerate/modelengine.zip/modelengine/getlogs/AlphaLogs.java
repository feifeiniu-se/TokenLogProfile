/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cn.edu.nju.software.modelengine.getlogs;

/**
 *
 * @author lichuanyi
 */
public class AlphaLogs {
    
	
	
}
